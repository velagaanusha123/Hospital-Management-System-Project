const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Routes
app.use('/api', require('./routes/auth'));
app.use('/api', require('./routes/patients'));
app.use('/api', require('./routes/appointments'));
app.use('/api', require('./routes/staff'));
app.use('/api', require('./routes/dashboard'));
app.use('/api', require('./routes/ai'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 RapidMed server running on port ${PORT}`));
