const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment');
const { protect } = require('../middleware/auth');

// GET /api/appointments - Get all appointments (optional date filter)
router.get('/appointments', async (req, res) => {
  try {
    const { date } = req.query;
    let query = {};
    if (date) query.date = date;

    const appointments = await Appointment.find(query).sort({ time: 1 });
    res.json(appointments);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/appointments/:id
router.get('/appointments/:id', async (req, res) => {
  try {
    const appt = await Appointment.findById(req.params.id);
    if (!appt) return res.status(404).json({ success: false, message: 'Appointment not found' });
    res.json(appt);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/appointments - Create appointment
router.post('/appointments', protect, async (req, res) => {
  try {
    const appt = await Appointment.create(req.body);
    res.status(201).json({ success: true, data: appt });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// PUT /api/appointments/:id - Update appointment
router.put('/appointments/:id', protect, async (req, res) => {
  try {
    const appt = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!appt) return res.status(404).json({ success: false, message: 'Appointment not found' });
    res.json({ success: true, data: appt });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// DELETE /api/appointments/:id
router.delete('/appointments/:id', protect, async (req, res) => {
  try {
    const appt = await Appointment.findByIdAndDelete(req.params.id);
    if (!appt) return res.status(404).json({ success: false, message: 'Appointment not found' });
    res.json({ success: true, message: 'Appointment deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
