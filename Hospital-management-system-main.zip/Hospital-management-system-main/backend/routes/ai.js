const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');

// POST /api/ai/chat
router.post('/ai/chat', protect, async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ success: false, message: 'Messages array required' });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1024,
        system: `You are RapidAI, an intelligent medical assistant for Rapid Med hospital in South India. 
You assist doctors, nurses, and medical staff with:
- Symptom analysis and differential diagnosis suggestions
- Drug information and interaction checks
- Medical procedure explanations  
- ICD-10 coding guidance
- Clinical terminology and reference
- Triage support and patient condition summaries

Always be professional, concise, and medically accurate. 
Always end responses with a reminder that your suggestions are for reference only and clinical judgment should prevail.
Keep responses focused and practical for a busy hospital setting.`,
        messages: messages
      })
    });

    const data = await response.json();

    if (data.content && data.content[0]) {
      res.json({ success: true, reply: data.content[0].text });
    } else {
      res.status(500).json({ success: false, message: 'AI response error' });
    }
  } catch (err) {
    console.error('AI error:', err);
    res.status(500).json({ success: false, message: 'AI service unavailable' });
  }
});

module.exports = router;
