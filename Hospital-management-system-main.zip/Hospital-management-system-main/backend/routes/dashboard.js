const express = require('express');
const router = express.Router();
const Patient = require('../models/Patient');
const Appointment = require('../models/Appointment');
const Staff = require('../models/Staff');

// GET /api/dashboard - Aggregate stats
router.get('/dashboard', async (req, res) => {
  try {
    const totalPatients = await Patient.countDocuments();
    const criticalPatients = await Patient.countDocuments({ status: 'Critical' });
    const stablePatients = await Patient.countDocuments({ status: 'Stable' });
    const dischargedPatients = await Patient.countDocuments({ status: 'Discharged' });

    const today = new Date().toISOString().split('T')[0];
    const opdToday = await Appointment.countDocuments({ date: today });
    const totalAppointments = await Appointment.countDocuments();
    const scheduledAppts = await Appointment.countDocuments({ status: 'Scheduled' });

    const onDutyStaff = await Staff.countDocuments({ status: 'ON-DUTY' });
    const totalStaff = await Staff.countDocuments();

    // Last 7 days admissions
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const start = new Date(d.setHours(0, 0, 0, 0));
      const end = new Date(d.setHours(23, 59, 59, 999));
      const count = await Patient.countDocuments({ createdAt: { $gte: start, $lte: end } });
      last7Days.push({ date: start.toLocaleDateString('en-IN', { weekday: 'short' }), count });
    }

    res.json({
      success: true,
      stats: {
        totalPatients,
        criticalPatients,
        stablePatients,
        dischargedPatients,
        opdToday,
        totalAppointments,
        scheduledAppts,
        onDutyStaff,
        totalStaff,
        last7Days
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
