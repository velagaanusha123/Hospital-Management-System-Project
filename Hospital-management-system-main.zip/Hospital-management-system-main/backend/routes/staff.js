const express = require('express');
const router = express.Router();
const Staff = require('../models/Staff');
const { protect } = require('../middleware/auth');

// GET /api/staff - Get all staff
router.get('/staff', async (req, res) => {
  try {
    const staff = await Staff.find().sort({ createdAt: -1 });
    res.json(staff);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/staff - Add staff member
router.post('/staff', protect, async (req, res) => {
  try {
    // Auto-generate initials if not provided
    if (!req.body.initials && req.body.name) {
      const parts = req.body.name.replace('Dr. ', '').replace('Nurse ', '').split(' ');
      req.body.initials = parts.map(p => p[0]).join('').toUpperCase().slice(0, 2);
    }
    const staff = await Staff.create(req.body);
    res.status(201).json({ success: true, data: staff });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// PUT /api/staff/:id - Update staff status etc.
router.put('/staff/:id', protect, async (req, res) => {
  try {
    const staff = await Staff.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!staff) return res.status(404).json({ success: false, message: 'Staff not found' });
    res.json({ success: true, data: staff });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// DELETE /api/staff/:id
router.delete('/staff/:id', protect, async (req, res) => {
  try {
    const staff = await Staff.findByIdAndDelete(req.params.id);
    if (!staff) return res.status(404).json({ success: false, message: 'Staff not found' });
    res.json({ success: true, message: 'Staff member removed' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
