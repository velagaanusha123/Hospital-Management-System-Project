const mongoose = require('mongoose');

const staffSchema = new mongoose.Schema({
  name: { type: String, required: true },
  role: { type: String, required: true },
  department: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  status: { type: String, enum: ['ON-DUTY', 'OFF-DUTY', 'IN-SURGERY'], default: 'ON-DUTY' },
  initials: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Staff', staffSchema);
