const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  name: { type: String, required: true },
  age: { type: Number, required: true },
  gender: { type: String, enum: ['Male', 'Female', 'Other'], required: true },
  condition: { type: String, required: true },
  bloodType: { type: String, enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
  status: { type: String, enum: ['Stable', 'Critical', 'Discharged'], default: 'Stable' },
  ward: { type: String, default: 'General' },
  admittedDate: { type: Date, default: Date.now },
  lastVisit: { type: Date, default: Date.now },
  phone: { type: String },
  address: { type: String },
  notes: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Patient', patientSchema);
