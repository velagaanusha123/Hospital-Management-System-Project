const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');

dotenv.config();

const User = require('./models/User');
const Patient = require('./models/Patient');
const Appointment = require('./models/Appointment');
const Staff = require('./models/Staff');

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected to MongoDB...');

  // Clear existing data
  await User.deleteMany();
  await Patient.deleteMany();
  await Appointment.deleteMany();
  await Staff.deleteMany();

  // Create admin user
  await User.create({
    name: 'Dr. S. Ramanujam',
    email: 'admin@rapidmed.in',
    password: 'password',
    role: 'Chief Surgeon',
    department: 'Surgery'
  });

  console.log('✅ User created: admin@rapidmed.in / password');

  // Create staff
  await Staff.insertMany([
    { name: 'Dr. Thangavelu P.', role: 'Head of Cardiology', department: 'Cardiology Department', email: 'thanga@rapidmed.in', status: 'ON-DUTY', initials: 'T' },
    { name: 'Dr. Janaki Iyer', role: 'Orthopedic Surgeon', department: 'Orthopedics Department', email: 'janaki@rapidmed.in', status: 'IN-SURGERY', initials: 'JI' },
    { name: 'Dr. Srinivas Rao', role: 'General Physician', department: 'Internal Medicine Department', email: 'srinivas@rapidmed.in', status: 'ON-DUTY', initials: 'SR' },
    { name: 'Dr. Meenakshi S.', role: 'Radiologist', department: 'Radiology Department', email: 'meenakshi@rapidmed.in', status: 'OFF-DUTY', initials: 'M' },
    { name: 'Nurse Revathi', role: 'Chief Nurse', department: 'Nursing Department', email: 'revathi@rapidmed.in', status: 'ON-DUTY', initials: 'NR' },
    { name: 'Dr. Balaji K.', role: 'Pediatrician', department: 'Pediatrics Department', email: 'balaji@rapidmed.in', status: 'ON-DUTY', initials: 'B' }
  ]);

  console.log('✅ Staff seeded');

  // Create patients
  await Patient.insertMany([
    { name: 'Murali Krishna', age: 45, gender: 'Male', condition: 'Hypertension', bloodType: 'B+', status: 'Stable', lastVisit: new Date() },
    { name: 'Lakshmi Devi', age: 62, gender: 'Female', condition: 'Diabetes Type 2', bloodType: 'O+', status: 'Critical', lastVisit: new Date() },
    { name: 'Suresh Kumar', age: 38, gender: 'Male', condition: 'Fracture - Left Femur', bloodType: 'A+', status: 'Stable', lastVisit: new Date() },
    { name: 'Chithra Viswanathan', age: 54, gender: 'Female', condition: 'Coronary Artery Disease', bloodType: 'AB+', status: 'Stable', lastVisit: new Date() },
    { name: 'Karthikeyan G.', age: 8, gender: 'Male', condition: 'Asthma', bloodType: 'B-', status: 'Discharged', lastVisit: new Date() },
    { name: 'Padmavathi R.', age: 71, gender: 'Female', condition: 'Osteoporosis', bloodType: 'O-', status: 'Stable', lastVisit: new Date() }
  ]);

  console.log('✅ Patients seeded');

  // Create appointments
  const today = new Date().toISOString().split('T')[0];
  await Appointment.insertMany([
    { patientName: 'Suresh Kumar', doctorName: 'Dr. Thangavelu P.', date: today, time: '09:00 AM', type: 'Checkup', status: 'Scheduled' },
    { patientName: 'Chithra Viswanathan', doctorName: 'Dr. Srinivas Rao', date: today, time: '10:30 AM', type: 'Cardiology', status: 'Completed' },
    { patientName: 'Lakshmi Narayanan', doctorName: 'Dr. Janaki Iyer', date: today, time: '01:00 PM', type: 'Dermatology', status: 'Scheduled' },
    { patientName: 'Karthikeyan G.', doctorName: 'Dr. Balaji K.', date: today, time: '11:00 AM', type: 'Pediatrics', status: 'Cancelled' }
  ]);

  console.log('✅ Appointments seeded');
  console.log('\n🎉 Database seeded successfully!');
  console.log('Login: admin@rapidmed.in | password');

  process.exit();
};

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
