# 🏥 RapidMed - Hospital Management System

Full-stack Hospital Management System with MongoDB backend and AI assistant.

---

## 📁 Project Structure

```
rapidmed/
├── backend/
│   ├── models/
│   │   ├── User.js
│   │   ├── Patient.js
│   │   ├── Appointment.js
│   │   └── Staff.js
│   ├── routes/
│   │   ├── auth.js        → Login / Register
│   │   ├── patients.js    → Patient CRUD
│   │   ├── appointments.js → Appointment CRUD
│   │   ├── staff.js       → Staff CRUD
│   │   ├── dashboard.js   → Live stats
│   │   └── ai.js          → RapidAI chat (Claude)
│   ├── middleware/
│   │   └── auth.js        → JWT protection
│   ├── server.js
│   ├── seed.js            → Populate demo data
│   ├── .env
│   └── package.json
└── frontend/
    ├── login.html
    ├── dashboard.html
    ├── patients.html
    ├── appointment.html
    ├── staffdirectories.html
    └── rapidai.html
```

---

## ⚡ Quick Setup

### 1. Prerequisites
- Node.js (v16+)
- MongoDB running locally on port 27017
  - Install: https://www.mongodb.com/try/download/community
  - Start: `mongod` or via MongoDB Compass

### 2. Backend Setup

```bash
cd backend
npm install
```

### 3. Configure Environment

Edit `backend/.env`:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/rapidmed
JWT_SECRET=rapidmed_super_secret_key_2024
ANTHROPIC_API_KEY=your_anthropic_api_key_here   ← Add your key for RapidAI
```

Get your Anthropic API key at: https://console.anthropic.com

### 4. Seed the Database (Demo Data)

```bash
cd backend
node seed.js
```

This creates:
- ✅ Admin user: `admin@rapidmed.in` / `password`
- ✅ 6 staff members
- ✅ 6 patients  
- ✅ 4 appointments for today

### 5. Start the Backend

```bash
cd backend
npm start
# Server runs on http://localhost:5000
```

### 6. Open the Frontend

Simply open `frontend/login.html` in your browser.

Or serve with a simple HTTP server:
```bash
cd frontend
npx serve .
# Opens on http://localhost:3000
```

---

## 🔐 Login Credentials

| Email | Password |
|-------|----------|
| admin@rapidmed.in | password |

---

## 🌐 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/login | Login user |
| POST | /api/register | Register new user |

### Patients
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/patients | Get all patients |
| GET | /api/patients?search=name | Search by name |
| GET | /api/patients?status=Critical | Filter by status |
| POST | /api/patients | Add patient (auth required) |
| PUT | /api/patients/:id | Update patient (auth required) |
| DELETE | /api/patients/:id | Delete patient (auth required) |

### Appointments
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/appointments | Get all appointments |
| GET | /api/appointments?date=YYYY-MM-DD | Filter by date |
| POST | /api/appointments | Create appointment (auth) |
| PUT | /api/appointments/:id | Update appointment (auth) |
| DELETE | /api/appointments/:id | Delete appointment (auth) |

### Staff
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/staff | Get all staff |
| POST | /api/staff | Add staff member (auth) |
| PUT | /api/staff/:id | Update staff (auth) |
| DELETE | /api/staff/:id | Remove staff (auth) |

### Dashboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/dashboard | Get live stats |

### AI Assistant
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/ai/chat | Chat with RapidAI (auth) |

---

## ✨ Features

- **Login** — JWT authentication with token stored in localStorage
- **Dashboard** — Live stats from DB, 7-day admissions chart, recent patients
- **Patients** — Full CRUD with modal form, search & filter by status
- **Appointments** — Calendar view, add/complete/cancel/delete appointments
- **Staff Directory** — Add/edit/delete staff, toggle ON-DUTY/OFF-DUTY status
- **RapidAI** — Real AI chat powered by Claude (Anthropic API), medical context

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML, CSS, Vanilla JS |
| Backend | Node.js + Express |
| Database | MongoDB + Mongoose |
| Auth | JWT (jsonwebtoken) + bcryptjs |
| AI | Anthropic Claude API |
